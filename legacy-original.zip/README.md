# Check of arXiv:2404.08633v3

**Does DESI 2024 Confirm ΛCDM?** — E. Ó Colgáin, M. G. Dainotti, S. Capozziello, S. Pourojaghi, M. M. Sheikh-Jabbari, D. Stojkovic. JHEAp ([doi:10.1016/j.jheap.2025.100428](https://doi.org/10.1016/j.jheap.2025.100428)). [arXiv:2404.08633v3](https://arxiv.org/abs/2404.08633v3).

**Result: Reproduced, with notes (checked scope).** We re-ran the paper's flat ΛCDM and w0waCDM analyses of DESI DR1 BAO data from its equations with our own code. The headline numbers reproduce: Ωm ≈ 0.67 for the LRG bin at z = 0.51 (about 2σ from Planck), and that bin driving DESI-alone w0 above −1. We have three minor notes and one remark of context; none overturns the main qualitative conclusions within the checked scope. This is a scoped reproduction, not a certification of the entire paper.

> **Draft, not released.** Local release candidate; owner approval and a fresh-conversation verification are pending.

## What we checked

- Eqs. (1)–(2): the D_M/D_H ratio as a function of Ωm, its limits and inversion
- Tables I–III: per-bin Ωm (ratio method and MCMC) and the binned fits
- The p-value and σ for the z = 0.51 bin against Planck
- Full-sample Ωm and the tensions with Planck, Pantheon+, Union3 and DES
- Section III: DESI-alone w0waCDM with and without the z = 0.51 bin, conditional on its printed priors; wa remains weakly constrained
- The 'under pressure at close to 3σ' sentence

**Not checked:**

- The survey of other probes (lensing time delays, quasars, GRBs, supernova samples)
- DESI's own BAO pipeline
- The Planck and supernova Ωm values, which are taken as printed

## Claims (9 checked)

| Claim | Where | Result | Output |
|---|---|---|---|
| C1 | Eq. (2), TeX l.218-222 | Reproduced | [`checks/out/c1.out`](checks/out/c1.out) |
| C2 | Table III, TeX l.227-243; method l.225 | Reproduced | [`checks/out-r2/c2c3_dr1.out`](checks/out-r2/c2c3_dr1.out) |
| C3 | TeX l.245, Fig. 3 caption l.251 | Reproduced: 2.154σ against the printed "no less than 2.2σ", so it passes only on rounding | [`checks/out-r2/c2c3_dr1.out`](checks/out-r2/c2c3_dr1.out) |
| C4 | Table I, TeX l.167-185; priors l.156 | Reproduced, with a note (N1) | [`checks/out-r2/c4.out`](checks/out-r2/c4.out) |
| C5 | TeX l.212-214 and footnote l.212 | Reproduced, with a note (N2) | [`checks/out-r2/c5_dr1.out`](checks/out-r2/c5_dr1.out) |
| C6 | TeX l.158, l.212, l.214 | Reproduced with a strict-tolerance exception: qualified reproduction: one refit (all DESI against DES) is about 2.80σ, 0.002σ beyond the frozen ±0.1σ tolerance around the printed 2.7σ; the strict criterion fails and remains disclosed | [`checks/out-r2/c6.out`](checks/out-r2/c6.out) |
| C7 | Table II, TeX l.192-210; abstract l.130 | Reproduced | [`checks/out-r2/c7_dr1.out`](checks/out-r2/c7_dr1.out) |
| C8 | Sec. III, TeX l.258-269, Fig. 4 | Reproduced | [`checks/out-r3/c8_dr1_2dp.out`](checks/out-r3/c8_dr1_2dp.out) |
| C9 | TeX l.214 | Context reviewed: see Context below | [`checks/out-r2/c9_dr1.out`](checks/out-r2/c9_dr1.out) |

The original scientific plan and its dated amendments are preserved in `PROTOCOL.md`. It includes expectations later corrected. Release replay gates are separate, post-hoc engineering checks in `VALIDATION.md`; they do not erase scientific exceptions. Printed inputs are in `paper_values.json`.

## Notes

- **N1** (S0, Table I (z = 0.51 row); prior statement l.156). For the LRG bin at z = 0.51, extending the printed Ωm upper prior bound changes the upper credible-interval offset from about 0.18 to 0.23, while the approximately two-sigma discrepancy with Planck is preserved. The statement that the priors do not affect the results holds for the main qualitative conclusion, not for this upper interval. [`checks/out-r3/notes.out`](checks/out-r3/notes.out)
- **N2** (S0, l.212–214 and footnote). The paper discloses its use of rounded effective redshifts. With the release-file redshifts, the DES discrepancy is about 2.53σ for all bins and 2.50σ after removing the z = 0.51 bin, so the small increase reported after removal is not robust to input precision. [`checks/out-r2/c6.out`](checks/out-r2/c6.out)
- **N4** (S0, l.222). With the stated DESI convention, D_M/D_H equals the fiducial D_M/D_H ratio divided by α_AP. The sentence identifying the two quantities could be clarified; the paper's distance-ratio equation and all reproduced calculations are unaffected. [`checks/out-r3/notes.out`](checks/out-r3/notes.out)

**Context.** The near-three-sigma statement (l.214) compares DESI and DES under a common cosmological model; it is not a DESI-only detection of Ωm changing with redshift. For paper-rounded redshifts, the global DESI DR1 flat-ΛCDM fit has χ² = 13.56 for 10 degrees of freedom (PTE = 0.194). Separate post-hoc nested comparisons give asymptotic p = 0.18 and 0.54 (checks/out-r2/c9_dr1.out); these compare models and are not goodness-of-fit probabilities.

## Newer data

- **M1** (desi-dr2-bao). z = 0.51 bin against Planck: 2.15σ on DR1 (checks/out-r2/c2c3_dr1.out), 1.59σ on DR2. This retrospective update is consistent with the weakening discussed by the authors; the frozen v3 paper already cites their DR2 follow-up. [`checks/out-r2/c2c3_dr2.out`](checks/out-r2/c2c3_dr2.out)
- **M2** (desi-dr2-bao). With release-file redshifts for both releases, the rise in Ωm from the middle to the high-redshift bin is 1.69σ on DR1 (checks/out-r2/c7_dr1.out), 0.56σ on DR2. [`checks/out-r2/c7_dr2.out`](checks/out-r2/c7_dr2.out)
- **M3** (desi-dr2-bao). Removing the z = 0.51 bin moves DESI-alone w0 by −0.39 on DR1 (checks/out-r3/c8_dr1_3dp.out) but only −0.03 on DR2, both with release-file redshifts: that bin no longer drives w0 > −1, in line with the authors' own DR2 follow-up (arXiv:2504.04417). [`checks/out-r3/c8_dr2_3dp.out`](checks/out-r3/c8_dr2_3dp.out)

A re-test on newer data describes how the model fares; it does not change whether the paper's own work reproduces.

## Datasets

| Dataset | Release | Role | Used for | Links |
|---|---|---|---|---|
| DESI DR1 BAO distances (Gaussian likelihood, all tracers) | DR1 (2024) | data the paper used | C1, C2, C3, C4, C5, C6, C7, C8, C9 | [source](https://data.desi.lbl.gov/doc/releases/dr1/) · [DESI DR1 data release paper](https://arxiv.org/abs/2503.14745) · [DESI 2024 III](https://arxiv.org/abs/2404.03000) · [DESI 2024 IV](https://arxiv.org/abs/2404.03001) · [DESI 2024 VI](https://arxiv.org/abs/2404.03002) · [desi_2024_gaussian_bao_ALL_GCcomb_mean.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_2024_gaussian_bao_ALL_GCcomb_mean.txt) · [desi_2024_gaussian_bao_ALL_GCcomb_cov.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_2024_gaussian_bao_ALL_GCcomb_cov.txt) |
| DESI DR2 BAO distances (Gaussian likelihood, all tracers) | DR2 (2025) | newer release of the paper's data | M1, M2, M3 | [source](https://data.desi.lbl.gov/public/papers/y3/bao-cosmo-params/README.html) · [DESI DR2 Results II](https://arxiv.org/abs/2503.14738) · [DESI DR2 Results I](https://arxiv.org/abs/2503.14739) · [desi_gaussian_bao_ALL_GCcomb_mean.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_mean.txt) · [desi_gaussian_bao_ALL_GCcomb_cov.txt](https://raw.githubusercontent.com/CobayaSampler/bao_data/bb0c1c9009dc76d1391300e169e8df38fd1096db/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_cov.txt) |
| Planck 2018 ΛCDM parameters (Ωm = 0.315 ± 0.007) | PR3 (2018) | published value, taken as printed | C3, C4, C6 | [source](https://pla.esac.esa.int/) · [Planck 2018 results VI](https://arxiv.org/abs/1807.06209) |
| Pantheon+ supernovae (Ωm = 0.334 ± 0.018) | 2022 | published value, taken as printed | C6 | [source](https://github.com/PantheonPlusSH0ES/DataRelease) · [The Pantheon+ analysis](https://arxiv.org/abs/2202.04077) |
| Union3 supernovae (Ωm = 0.356 +0.028 −0.026) | 2023 | published value, taken as printed | C6 | [source](https://arxiv.org/abs/2311.12098) · [Union through UNITY](https://arxiv.org/abs/2311.12098) |
| DES 5-year supernovae (Ωm = 0.352 ± 0.017) | SN5YR (2024) | published value, taken as printed | C5, C6, C9 | [source](https://github.com/des-science/DES-SN5YR/releases/tag/1.3) · [DES](https://arxiv.org/abs/2401.02929) |

**DESI DR1 BAO distances (Gaussian likelihood, all tracers); DESI DR2 BAO distances (Gaussian likelihood, all tracers).** This research used data obtained with the Dark Energy Spectroscopic Instrument (DESI). DESI construction and operations is managed by the Lawrence Berkeley National Laboratory. This material is based upon work supported by the U.S. Department of Energy, Office of Science, Office of High-Energy Physics, under Contract No. DE–AC02–05CH11231, and by the National Energy Research Scientific Computing Center, a DOE Office of Science User Facility under the same contract. Additional support for DESI was provided by the U.S. National Science Foundation (NSF), Division of Astronomical Sciences under Contract No. AST-0950945 to the NSF’s National Optical-Infrared Astronomy Research Laboratory; the Science and Technology Facilities Council of the United Kingdom; the Gordon and Betty Moore Foundation; the Heising-Simons Foundation; the French Alternative Energies and Atomic Energy Commission (CEA); the National Council of Humanities, Science and Technology of Mexico (CONAHCYT); the Ministry of Science and Innovation of Spain (MICINN), and by the DESI Member Institutions: www.desi.lbl.gov/collaborating-institutions. The DESI collaboration is honored to be permitted to conduct scientific research on I’oligam Du’ag (Kitt Peak), a mountain with particular significance to the Tohono O’odham Nation. Any opinions, findings, and conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the U.S. National Science Foundation, the U.S. Department of Energy, or any of the listed funding agencies.

Data files are not copied here. `python3 fetch_data.py` downloads them from the pinned links above and checks their SHA-256.

## How it was done

The checks were written and run with AI models in subscription sessions, overseen by one researcher who reviews each step and approves each release. Model agreement is not treated as confirmation.

| Model | Role | Tokens in / out | Model time |
|---|---|---|---|
| `claude-opus-5-5`, Claude Code (cloud project thread) | first check, corrections and responses; coordination | 56.3M / 210k | 52 min |
| `gpt-6-astra` (high), Codex Desktop 0.160.1 | independent re-check with its own code; critic: tried to drop or soften each note | 14.9M / 79k | 61 min |

Total: 608k uncached input tokens (excluding cache writes), 913k cache-write tokens and 69.7M cache-read tokens, 288k output tokens, 113 minutes of model time. Read from each session's own log (Codex rollout files; Claude Code session records). Sessions ran on subscriptions, so no per-token price applies. Model time is the time the model was working, tool runs included. Not every check ran in a fresh conversation: the independent re-check and the critique ran in the same conversation. Per-stage figures are in `effort.json`. These recorded figures cover the scientific review stages, not subsequent package preparation or final verification; no unmeasured work is included in the totals.

## Run it

```sh
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m unittest test_validation.py
python3 reproduce.py --all    # full suite; required for release verification
```

Runtime: hardware dependent; allow roughly 5–30 minutes for the full suite, including any permitted sampler extension.

All published files are SHA-256 checked before and after execution. New outputs and chains are retained under `_runs/`; references are never overwritten. Omitting `--all` runs only the core suite, which still includes per-bin MCMC controls. A successful replay does not mean every original scientific criterion passed: the C6 exception remains.

## Cite

Cite the original paper first. To cite this check, use `CITATION.cff`. Code: BSD-3-Clause. Text: CC BY 4.0.
